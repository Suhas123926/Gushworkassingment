const stickyHeader = document.getElementById('stickyHeader');

window.addEventListener('scroll', () => {
  if (window.scrollY > window.innerHeight - 100) {
    stickyHeader.classList.add('active');
  } else {
    stickyHeader.classList.remove('active');
  }
});

const track = document.getElementById('carouselTrack');
const nextBtn = document.getElementById('nextBtn');
const prevBtn = document.getElementById('prevBtn');

const slides = document.querySelectorAll('.carousel-item');
let currentIndex = 0;

function updateCarousel() {
  const slideWidth = slides[0].clientWidth;
  track.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
}

nextBtn.addEventListener('click', () => {
  currentIndex++;

  if (currentIndex >= slides.length) {
    currentIndex = 0;
  }

  updateCarousel();
});

prevBtn.addEventListener('click', () => {
  currentIndex--;

  if (currentIndex < 0) {
    currentIndex = slides.length - 1;
  }

  updateCarousel();
});

window.addEventListener('resize', updateCarousel);
